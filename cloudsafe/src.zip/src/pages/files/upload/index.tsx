import {
  CloudUploadOutlined,
  FileProtectOutlined,
  InfoCircleOutlined,
  LockOutlined,
  SafetyCertificateOutlined,
} from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import {
  Alert,
  Button,
  Card,
  Col,
  Divider,
  Progress,
  Row,
  Space,
  Steps,
  Tag,
  Typography,
  Upload,
  message,
} from 'antd';
import type { UploadFile } from 'antd';
import React, { useState } from 'react';

const { Title, Text, Paragraph } = Typography;
const { Dragger } = Upload;

type UploadStatus = 'idle' | 'encrypting' | 'uploading' | 'done' | 'error';

const UploadPage: React.FC = () => {
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [status, setStatus] = useState<UploadStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [encryptedInfo, setEncryptedInfo] = useState<{
    aesKey: string;
    iv: string;
    rsaEncryptedKey: string;
    fileSize: string;
  } | null>(null);

  const simulateEncryptAndUpload = async (file: File) => {
    setStatus('encrypting');
    setCurrentStep(0);
    setProgress(0);

    // Step 1: Generate AES key (simulated)
    await new Promise((r) => setTimeout(r, 600));
    setProgress(15);

    // Step 2: Encrypt file with AES-GCM
    setCurrentStep(1);
    for (let p = 15; p <= 60; p += 5) {
      await new Promise((r) => setTimeout(r, 80));
      setProgress(p);
    }

    // Step 3: Encrypt AES key with RSA
    setCurrentStep(2);
    await new Promise((r) => setTimeout(r, 500));
    setProgress(75);

    // Step 4: Upload
    setStatus('uploading');
    setCurrentStep(3);
    for (let p = 75; p <= 99; p += 3) {
      await new Promise((r) => setTimeout(r, 100));
      setProgress(p);
    }

    setProgress(100);
    setCurrentStep(4);
    setStatus('done');

    // Mock result info
    const mockAES = Array.from(crypto.getRandomValues(new Uint8Array(8)))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    const mockIV = Array.from(crypto.getRandomValues(new Uint8Array(6)))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    const mockRSA = Array.from(crypto.getRandomValues(new Uint8Array(12)))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');

    setEncryptedInfo({
      aesKey: mockAES + '...',
      iv: mockIV + '...',
      rsaEncryptedKey: mockRSA + '...',
      fileSize: `${(file.size / 1024).toFixed(1)} KB`,
    });

    message.success(`Tải lên thành công: ${file.name}`);
  };

  const handleUpload = () => {
    if (fileList.length === 0) {
      message.warning('Vui lòng chọn file trước!');
      return;
    }
    const file = fileList[0].originFileObj as File;
    if (file) simulateEncryptAndUpload(file);
  };

  const handleReset = () => {
    setFileList([]);
    setStatus('idle');
    setProgress(0);
    setCurrentStep(0);
    setEncryptedInfo(null);
  };

  const steps = [
    { title: 'Sinh AES Key', description: 'Tạo khóa AES-256 ngẫu nhiên' },
    { title: 'Mã hóa file', description: 'AES-256-GCM encrypt' },
    { title: 'Mã hóa khóa', description: 'RSA-OAEP encrypt AES key' },
    { title: 'Tải lên server', description: 'Upload ciphertext + encrypted key' },
    { title: 'Hoàn thành', description: 'File đã được lưu an toàn' },
  ];

  return (
    <PageContainer
      title="Tải lên file mã hóa"
      subTitle="Mã hóa AES-256-GCM + RSA-OAEP tại trình duyệt trước khi tải lên"
    >
      <Row gutter={[24, 24]}>
        <Col xs={24} lg={16}>
          <Card title={<><CloudUploadOutlined /> Chọn file</>}>
            <Alert
              type="info"
              showIcon
              icon={<LockOutlined />}
              message="Bảo mật Zero-Knowledge"
              description="File được mã hóa hoàn toàn TẠI TRÌNH DUYỆT của bạn. Server chỉ nhận dữ liệu đã mã hóa — không bao giờ thấy nội dung gốc."
              style={{ marginBottom: 24 }}
            />

            <Dragger
              fileList={fileList}
              beforeUpload={(file) => {
                setFileList([{ ...file, uid: file.name, name: file.name, originFileObj: file } as UploadFile]);
                return false;
              }}
              onRemove={() => {
                setFileList([]);
                setStatus('idle');
              }}
              disabled={status === 'encrypting' || status === 'uploading'}
            >
              <p className="ant-upload-drag-icon">
                <FileProtectOutlined style={{ fontSize: 48, color: '#1677ff' }} />
              </p>
              <p className="ant-upload-text">Kéo thả file vào đây hoặc nhấn để chọn</p>
              <p className="ant-upload-hint">
                Hỗ trợ mọi loại file. File sẽ được mã hóa AES-256 trước khi tải lên.
              </p>
            </Dragger>

            {fileList.length > 0 && status === 'idle' && (
              <Button
                type="primary"
                size="large"
                icon={<LockOutlined />}
                onClick={handleUpload}
                style={{ marginTop: 16, width: '100%' }}
              >
                Mã hóa & Tải lên
              </Button>
            )}
          </Card>

          {(status === 'encrypting' || status === 'uploading' || status === 'done') && (
            <Card title="Tiến trình" style={{ marginTop: 24 }}>
              <Steps
                current={currentStep}
                size="small"
                items={steps.map((s) => ({ title: s.title, description: s.description }))}
                style={{ marginBottom: 24 }}
              />
              <Progress
                percent={progress}
                status={status === 'done' ? 'success' : status === 'error' ? 'exception' : 'active'}
                strokeColor={status === 'done' ? '#52c41a' : '#1677ff'}
              />
              {status === 'encrypting' && (
                <Text type="secondary" style={{ display: 'block', marginTop: 8 }}>
                  🔐 Đang mã hóa tại trình duyệt...
                </Text>
              )}
              {status === 'uploading' && (
                <Text type="secondary" style={{ display: 'block', marginTop: 8 }}>
                  ☁️ Đang tải dữ liệu đã mã hóa lên server...
                </Text>
              )}
              {status === 'done' && (
                <>
                  <Alert
                    type="success"
                    showIcon
                    message="Tải lên thành công!"
                    description="File đã được mã hóa và lưu trữ an toàn trên server."
                    style={{ marginTop: 16 }}
                  />
                  <Button onClick={handleReset} style={{ marginTop: 12 }}>
                    Tải lên file khác
                  </Button>
                </>
              )}
            </Card>
          )}

          {encryptedInfo && (
            <Card
              title={<><SafetyCertificateOutlined style={{ color: '#52c41a' }} /> Thông tin mã hóa</>}
              style={{ marginTop: 24 }}
            >
              <Space direction="vertical" style={{ width: '100%' }}>
                <Row>
                  <Col span={8}><Text type="secondary">Kích thước file:</Text></Col>
                  <Col span={16}><Tag color="blue">{encryptedInfo.fileSize}</Tag></Col>
                </Row>
                <Row>
                  <Col span={8}><Text type="secondary">Thuật toán:</Text></Col>
                  <Col span={16}>
                    <Tag color="purple">AES-256-GCM</Tag>
                    <Tag color="orange">RSA-OAEP</Tag>
                  </Col>
                </Row>
                <Row>
                  <Col span={8}><Text type="secondary">AES Key (đã mã hóa RSA):</Text></Col>
                  <Col span={16}><Text code>{encryptedInfo.rsaEncryptedKey}</Text></Col>
                </Row>
                <Row>
                  <Col span={8}><Text type="secondary">IV (nonce):</Text></Col>
                  <Col span={16}><Text code>{encryptedInfo.iv}</Text></Col>
                </Row>
              </Space>
            </Card>
          )}
        </Col>

        <Col xs={24} lg={8}>
          <Card title={<><InfoCircleOutlined /> Quy trình Upload</>}>
            <Steps
              direction="vertical"
              size="small"
              current={99}
              items={[
                {
                  title: 'Sinh AES Key',
                  description: 'Tạo khóa AES-256 bits ngẫu nhiên bằng Web Crypto API',
                  status: 'finish',
                },
                {
                  title: 'Mã hóa file (AES-GCM)',
                  description: 'File gốc → AES-256-GCM encrypt → Ciphertext',
                  status: 'finish',
                },
                {
                  title: 'Mã hóa khóa AES (RSA-OAEP)',
                  description: 'AES key → RSA Public Key → Encrypted AES Key',
                  status: 'finish',
                },
                {
                  title: 'Tải lên server',
                  description: 'Upload (Ciphertext + Encrypted AES Key + IV)',
                  status: 'finish',
                },
              ]}
            />
          </Card>

          <Card title="Bảo mật" style={{ marginTop: 16 }}>
            <Space direction="vertical">
              <div>
                <Tag color="green">AES-256-GCM</Tag>
                <Text type="secondary" style={{ marginLeft: 8 }}>Mã hóa dữ liệu nhanh, có xác thực</Text>
              </div>
              <div>
                <Tag color="orange">RSA-OAEP</Tag>
                <Text type="secondary" style={{ marginLeft: 8 }}>Bảo vệ khóa AES an toàn</Text>
              </div>
              <div>
                <Tag color="blue">Zero-Knowledge</Tag>
                <Text type="secondary" style={{ marginLeft: 8 }}>Server không đọc được nội dung</Text>
              </div>
              <div>
                <Tag color="purple">Client-side</Tag>
                <Text type="secondary" style={{ marginLeft: 8 }}>Mã hóa tại trình duyệt</Text>
              </div>
            </Space>
          </Card>
        </Col>
      </Row>
    </PageContainer>
  );
};

export default UploadPage;
