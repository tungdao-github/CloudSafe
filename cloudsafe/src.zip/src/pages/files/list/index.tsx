import {
  CloudDownloadOutlined,
  DeleteOutlined,
  FileExcelOutlined,
  FilePdfOutlined,
  FileProtectOutlined,
  FileWordOutlined,
  FileZipOutlined,
  LockOutlined,
  ReloadOutlined,
  ShareAltOutlined,
  UnlockOutlined,
} from '@ant-design/icons';
import { PageContainer, ProTable } from '@ant-design/pro-components';
import type { ProColumns } from '@ant-design/pro-components';
import {
  Badge,
  Button,
  Col,
  Modal,
  Progress,
  Row,
  Space,
  Statistic,
  Tag,
  Tooltip,
  Typography,
  message,
} from 'antd';
import React, { useState } from 'react';

const { Text } = Typography;

interface FileItem {
  key: string;
  name: string;
  size: string;
  type: string;
  encryptedBy: string;
  owner: string;
  uploadedAt: string;
  status: 'encrypted' | 'decrypting' | 'shared';
  algorithm: string;
}

const mockFiles: FileItem[] = [
  { key: '1', name: 'Hop_dong_KH_2024.pdf', size: '2.4 MB', type: 'pdf', encryptedBy: 'AES-256-GCM + RSA-OAEP', owner: 'Nguyễn Văn An', uploadedAt: '2024-09-10 14:30', status: 'encrypted', algorithm: 'AES-256-GCM' },
  { key: '2', name: 'Bao_cao_tai_chinh_Q3.xlsx', size: '1.1 MB', type: 'xlsx', encryptedBy: 'AES-256-GCM + RSA-OAEP', owner: 'Trần Thị Bình', uploadedAt: '2024-09-09 09:15', status: 'encrypted', algorithm: 'AES-256-GCM' },
  { key: '3', name: 'Ho_so_nhan_su_thang_9.docx', size: '856 KB', type: 'docx', encryptedBy: 'AES-256-GCM + RSA-OAEP', owner: 'Lê Minh Cường', uploadedAt: '2024-09-08 16:45', status: 'shared', algorithm: 'AES-256-GCM' },
  { key: '4', name: 'Du_lieu_nghien_cuu.zip', size: '45.2 MB', type: 'zip', encryptedBy: 'AES-256-GCM + RSA-OAEP', owner: 'Phạm Thị Dung', uploadedAt: '2024-09-07 11:20', status: 'encrypted', algorithm: 'AES-256-GCM' },
  { key: '5', name: 'Tai_lieu_thiet_ke.pdf', size: '3.8 MB', type: 'pdf', encryptedBy: 'AES-256-GCM + RSA-OAEP', owner: 'Hoàng Văn Em', uploadedAt: '2024-09-06 08:00', status: 'encrypted', algorithm: 'AES-256-GCM' },
  { key: '6', name: 'Ke_hoach_kinh_doanh_2025.docx', size: '1.5 MB', type: 'docx', encryptedBy: 'AES-256-GCM + RSA-OAEP', owner: 'Nguyễn Văn An', uploadedAt: '2024-09-05 13:10', status: 'encrypted', algorithm: 'AES-256-GCM' },
];

const fileIcon = (type: string) => {
  const icons: Record<string, React.ReactNode> = {
    pdf: <FilePdfOutlined style={{ color: '#ff4d4f', fontSize: 20 }} />,
    xlsx: <FileExcelOutlined style={{ color: '#52c41a', fontSize: 20 }} />,
    docx: <FileWordOutlined style={{ color: '#1677ff', fontSize: 20 }} />,
    zip: <FileZipOutlined style={{ color: '#fa8c16', fontSize: 20 }} />,
  };
  return icons[type] || <FileProtectOutlined style={{ fontSize: 20 }} />;
};

const FileListPage: React.FC = () => {
  const [downloading, setDownloading] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState(0);

  const simulateDownload = async (file: FileItem) => {
    setDownloading(file.key);
    setDownloadProgress(0);

    // Step 1: Download encrypted file
    for (let p = 0; p <= 40; p += 5) {
      await new Promise((r) => setTimeout(r, 80));
      setDownloadProgress(p);
    }

    // Step 2: Decrypt AES key with RSA private key
    await new Promise((r) => setTimeout(r, 400));
    setDownloadProgress(65);

    // Step 3: Decrypt file with AES key
    for (let p = 65; p <= 100; p += 5) {
      await new Promise((r) => setTimeout(r, 60));
      setDownloadProgress(p);
    }

    message.success(`Đã giải mã và tải về: ${file.name}`);
    setDownloading(null);
    setDownloadProgress(0);
  };

  const columns: ProColumns<FileItem>[] = [
    {
      title: 'Tên file',
      dataIndex: 'name',
      render: (_, record) => (
        <Space>
          {fileIcon(record.type)}
          <span>{record.name}</span>
        </Space>
      ),
    },
    {
      title: 'Kích thước',
      dataIndex: 'size',
      width: 100,
    },
    {
      title: 'Chủ sở hữu',
      dataIndex: 'owner',
      width: 160,
    },
    {
      title: 'Thuật toán',
      dataIndex: 'algorithm',
      width: 140,
      render: (val) => <Tag color="purple">{val as string}</Tag>,
    },
    {
      title: 'Trạng thái',
      dataIndex: 'status',
      width: 120,
      render: (val) => {
        const map: Record<string, { color: string; label: string }> = {
          encrypted: { color: 'green', label: 'Đã mã hóa' },
          decrypting: { color: 'processing', label: 'Đang giải mã' },
          shared: { color: 'blue', label: 'Đã chia sẻ' },
        };
        const item = map[val as string] || { color: 'default', label: val as string };
        return <Badge status={item.color as any} text={item.label} />;
      },
    },
    {
      title: 'Ngày tải lên',
      dataIndex: 'uploadedAt',
      width: 160,
    },
    {
      title: 'Thao tác',
      width: 180,
      render: (_, record) => (
        <Space>
          {downloading === record.key ? (
            <Progress percent={downloadProgress} size="small" style={{ width: 80 }} />
          ) : (
            <Tooltip title="Giải mã & Tải về">
              <Button
                type="primary"
                size="small"
                icon={<UnlockOutlined />}
                onClick={() => simulateDownload(record)}
              >
                Tải về
              </Button>
            </Tooltip>
          )}
          <Tooltip title="Chia sẻ">
            <Button size="small" icon={<ShareAltOutlined />} />
          </Tooltip>
          <Tooltip title="Xóa">
            <Button size="small" danger icon={<DeleteOutlined />} />
          </Tooltip>
        </Space>
      ),
    },
  ];

  return (
    <PageContainer
      title="Danh sách file đã mã hóa"
      subTitle="Tất cả file được lưu trữ ở dạng mã hóa trên server"
    >
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={12} sm={6}>
          <Statistic title="Tổng file" value={mockFiles.length} prefix={<LockOutlined />} />
        </Col>
        <Col xs={12} sm={6}>
          <Statistic title="Đã mã hóa" value={mockFiles.filter((f) => f.status === 'encrypted').length} valueStyle={{ color: '#52c41a' }} />
        </Col>
        <Col xs={12} sm={6}>
          <Statistic title="Đã chia sẻ" value={mockFiles.filter((f) => f.status === 'shared').length} valueStyle={{ color: '#1677ff' }} />
        </Col>
        <Col xs={12} sm={6}>
          <Statistic title="Tổng dung lượng" value="54.9 MB" />
        </Col>
      </Row>

      <ProTable<FileItem>
        rowKey="key"
        dataSource={mockFiles}
        columns={columns}
        search={false}
        pagination={{ pageSize: 10 }}
        toolBarRender={() => [
          <Button key="refresh" icon={<ReloadOutlined />}>Làm mới</Button>,
          <Button key="upload" type="primary" icon={<CloudDownloadOutlined />} onClick={() => (window.location.href = '/files/upload')}>
            Tải lên file mới
          </Button>,
        ]}
      />
    </PageContainer>
  );
};

export default FileListPage;
