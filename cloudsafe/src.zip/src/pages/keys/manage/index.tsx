import {
  CopyOutlined,
  DeleteOutlined,
  DownloadOutlined,
  ExclamationCircleOutlined,
  KeyOutlined,
  LockOutlined,
  PlusOutlined,
  ReloadOutlined,
  SafetyCertificateOutlined,
  WarningOutlined,
} from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import {
  Alert,
  Badge,
  Button,
  Card,
  Col,
  Descriptions,
  Divider,
  Modal,
  Row,
  Space,
  Statistic,
  Steps,
  Tag,
  Timeline,
  Tooltip,
  Typography,
  message,
} from 'antd';
import React, { useState } from 'react';

const { Title, Text, Paragraph } = Typography;

interface KeyPair {
  id: string;
  name: string;
  algorithm: string;
  keySize: number;
  createdAt: string;
  status: 'active' | 'expired' | 'revoked';
  publicKeyFingerprint: string;
  usageCount: number;
}

const mockKeys: KeyPair[] = [
  {
    id: 'key-001',
    name: 'Khóa chính',
    algorithm: 'RSA-OAEP',
    keySize: 2048,
    createdAt: '2024-01-15 09:00',
    status: 'active',
    publicKeyFingerprint: 'SHA256:a3f8...c92e',
    usageCount: 47,
  },
  {
    id: 'key-002',
    name: 'Khóa dự phòng',
    algorithm: 'RSA-OAEP',
    keySize: 4096,
    createdAt: '2024-03-20 14:30',
    status: 'active',
    publicKeyFingerprint: 'SHA256:b7d1...f45a',
    usageCount: 12,
  },
  {
    id: 'key-003',
    name: 'Khóa cũ (đã thu hồi)',
    algorithm: 'RSA-OAEP',
    keySize: 2048,
    createdAt: '2023-06-01 08:00',
    status: 'revoked',
    publicKeyFingerprint: 'SHA256:e2c5...8b31',
    usageCount: 103,
  },
];

const KeyManagePage: React.FC = () => {
  const [generating, setGenerating] = useState(false);
  const [generateStep, setGenerateStep] = useState(-1);
  const [keys, setKeys] = useState<KeyPair[]>(mockKeys);

  const generateNewKey = async () => {
    setGenerating(true);
    setGenerateStep(0);
    await new Promise((r) => setTimeout(r, 800));
    setGenerateStep(1);
    await new Promise((r) => setTimeout(r, 600));
    setGenerateStep(2);
    await new Promise((r) => setTimeout(r, 400));
    setGenerateStep(3);

    const newKey: KeyPair = {
      id: `key-${Date.now()}`,
      name: 'Khóa mới',
      algorithm: 'RSA-OAEP',
      keySize: 2048,
      createdAt: new Date().toLocaleString('vi-VN'),
      status: 'active',
      publicKeyFingerprint: `SHA256:${Math.random().toString(36).slice(2, 6)}...${Math.random().toString(36).slice(2, 6)}`,
      usageCount: 0,
    };
    setKeys((prev) => [newKey, ...prev]);
    message.success('Đã tạo cặp khóa RSA-OAEP 2048-bit thành công!');
    setGenerating(false);
    setGenerateStep(-1);
  };

  const revokeKey = (keyId: string) => {
    Modal.confirm({
      title: 'Thu hồi khóa?',
      icon: <WarningOutlined style={{ color: '#ff4d4f' }} />,
      content: 'Sau khi thu hồi, các file mã hóa bằng khóa này sẽ KHÔNG thể giải mã được nữa. Hành động này không thể hoàn tác!',
      okText: 'Thu hồi',
      okType: 'danger',
      cancelText: 'Hủy',
      onOk() {
        setKeys((prev) => prev.map((k) => (k.id === keyId ? { ...k, status: 'revoked' as const } : k)));
        message.warning('Đã thu hồi khóa.');
      },
    });
  };

  const statusBadge = (status: string) => {
    const map: Record<string, { status: 'success' | 'error' | 'default'; label: string }> = {
      active: { status: 'success', label: 'Đang hoạt động' },
      expired: { status: 'error', label: 'Hết hạn' },
      revoked: { status: 'error', label: 'Đã thu hồi' },
    };
    const s = map[status] || { status: 'default', label: status };
    return <Badge status={s.status} text={s.label} />;
  };

  return (
    <PageContainer
      title="Quản lý khóa mã hóa"
      subTitle="RSA Public/Private Key pairs — Private key chỉ lưu tại trình duyệt của bạn"
    >
      <Alert
        type="warning"
        showIcon
        icon={<ExclamationCircleOutlined />}
        message="Private key KHÔNG bao giờ rời khỏi thiết bị của bạn"
        description="CloudSafe chỉ lưu Public Key trên server. Private key được lưu trong trình duyệt (IndexedDB) và chưa bao giờ được tải lên. Nếu mất private key, bạn sẽ không thể giải mã các file cũ."
        style={{ marginBottom: 24 }}
      />

      <Row gutter={[24, 24]}>
        <Col xs={24} lg={16}>
          <Card
            title={<><KeyOutlined /> Cặp khóa RSA của bạn</>}
            extra={
              <Button
                type="primary"
                icon={<PlusOutlined />}
                loading={generating}
                onClick={generateNewKey}
              >
                Tạo khóa mới
              </Button>
            }
          >
            {generating && (
              <Steps
                size="small"
                current={generateStep}
                style={{ marginBottom: 24 }}
                items={[
                  { title: 'Khởi tạo Web Crypto' },
                  { title: 'Sinh RSA-OAEP 2048-bit' },
                  { title: 'Lưu private key cục bộ' },
                  { title: 'Đăng ký public key' },
                ]}
              />
            )}

            <Space direction="vertical" style={{ width: '100%' }} size="middle">
              {keys.map((key) => (
                <Card
                  key={key.id}
                  size="small"
                  style={{
                    borderColor: key.status === 'active' ? '#52c41a' : '#d9d9d9',
                    opacity: key.status === 'revoked' ? 0.6 : 1,
                  }}
                >
                  <Row justify="space-between" align="middle">
                    <Col>
                      <Space>
                        <SafetyCertificateOutlined
                          style={{
                            fontSize: 24,
                            color: key.status === 'active' ? '#52c41a' : '#d9d9d9',
                          }}
                        />
                        <div>
                          <Title level={5} style={{ marginBottom: 2 }}>
                            {key.name}
                          </Title>
                          <Space size="small">
                            <Tag color="purple">{key.algorithm}</Tag>
                            <Tag color="blue">{key.keySize}-bit</Tag>
                            {statusBadge(key.status)}
                          </Space>
                        </div>
                      </Space>
                    </Col>
                    <Col>
                      <Space>
                        {key.status === 'active' && (
                          <>
                            <Tooltip title="Xuất public key">
                              <Button size="small" icon={<DownloadOutlined />} />
                            </Tooltip>
                            <Tooltip title="Sao chép fingerprint">
                              <Button
                                size="small"
                                icon={<CopyOutlined />}
                                onClick={() => {
                                  navigator.clipboard.writeText(key.publicKeyFingerprint);
                                  message.success('Đã sao chép fingerprint!');
                                }}
                              />
                            </Tooltip>
                            <Tooltip title="Thu hồi khóa">
                              <Button
                                size="small"
                                danger
                                icon={<DeleteOutlined />}
                                onClick={() => revokeKey(key.id)}
                              />
                            </Tooltip>
                          </>
                        )}
                      </Space>
                    </Col>
                  </Row>
                  <Divider style={{ margin: '12px 0' }} />
                  <Descriptions size="small" column={2}>
                    <Descriptions.Item label="Fingerprint">
                      <Text code style={{ fontSize: 11 }}>
                        {key.publicKeyFingerprint}
                      </Text>
                    </Descriptions.Item>
                    <Descriptions.Item label="Ngày tạo">{key.createdAt}</Descriptions.Item>
                    <Descriptions.Item label="Lượt sử dụng">{key.usageCount} file</Descriptions.Item>
                  </Descriptions>
                </Card>
              ))}
            </Space>
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          <Card title={<><LockOutlined /> Nguyên lý hoạt động</>} style={{ marginBottom: 16 }}>
            <Timeline
              items={[
                {
                  color: 'green',
                  children: (
                    <>
                      <Text strong>Đăng ký / Đăng nhập</Text>
                      <Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 0 }}>
                        Sinh cặp RSA key. Public key gửi lên server. Private key lưu trong trình duyệt.
                      </Paragraph>
                    </>
                  ),
                },
                {
                  color: 'blue',
                  children: (
                    <>
                      <Text strong>Upload file</Text>
                      <Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 0 }}>
                        AES key random → mã hóa file → RSA mã hóa AES key → upload (ciphertext + encrypted key).
                      </Paragraph>
                    </>
                  ),
                },
                {
                  color: 'orange',
                  children: (
                    <>
                      <Text strong>Download file</Text>
                      <Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 0 }}>
                        RSA private key giải mã AES key → AES key giải mã file → file gốc.
                      </Paragraph>
                    </>
                  ),
                },
              ]}
            />
          </Card>

          <Card title="Thống kê">
            <Row gutter={[16, 16]}>
              <Col span={12}>
                <Statistic
                  title="Khóa hoạt động"
                  value={keys.filter((k) => k.status === 'active').length}
                  valueStyle={{ color: '#52c41a' }}
                  prefix={<SafetyCertificateOutlined />}
                />
              </Col>
              <Col span={12}>
                <Statistic
                  title="Đã thu hồi"
                  value={keys.filter((k) => k.status === 'revoked').length}
                  valueStyle={{ color: '#ff4d4f' }}
                />
              </Col>
              <Col span={24}>
                <Statistic
                  title="Tổng file được bảo vệ"
                  value={keys.reduce((sum, k) => sum + k.usageCount, 0)}
                  prefix={<LockOutlined />}
                />
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    </PageContainer>
  );
};

export default KeyManagePage;
